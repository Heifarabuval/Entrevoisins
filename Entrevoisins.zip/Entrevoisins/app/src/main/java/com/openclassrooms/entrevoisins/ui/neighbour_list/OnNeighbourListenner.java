package com.openclassrooms.entrevoisins.ui.neighbour_list;

public interface OnNeighbourListenner {
    void NeighbourClick(int position) ;




}




